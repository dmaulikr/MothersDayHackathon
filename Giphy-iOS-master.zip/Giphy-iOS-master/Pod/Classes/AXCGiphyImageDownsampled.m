//
//  AXCGiphyImageDownsampled.m
//  AXCGiphy
//
//  Created by alexchoi on 8/18/14.
//  Copyright (c) 2014 Alex Choi. All rights reserved.
//

#import "AXCGiphyImageDownsampled.h"

@implementation AXCGiphyImageDownsampled

@end
