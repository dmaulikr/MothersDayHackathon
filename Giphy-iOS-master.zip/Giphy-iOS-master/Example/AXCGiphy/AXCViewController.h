//
//  AXCViewController.h
//  AXCGiphy
//
//  Created by Alex Choi on 08/19/2014.
//  Copyright (c) 2014 Alex Choi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AXCViewController : UIViewController

@property (nonatomic, strong) NSString *keyword1;
@property (nonatomic, strong) NSString *keyword2;
@property (nonatomic, strong) NSString *keyword3;
@property (nonatomic, strong) NSString *keyword4;
@property (nonatomic, strong) NSString *keyword5;


@end
