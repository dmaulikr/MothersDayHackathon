//
//  AXCAppDelegate.h
//  AXCGiphy
//
//  Created by CocoaPods on 08/19/2014.
//  Copyright (c) 2014 Alex Choi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AXCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
