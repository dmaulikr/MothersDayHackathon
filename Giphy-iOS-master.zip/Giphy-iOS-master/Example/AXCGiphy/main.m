//
//  main.m
//  AXCGiphy
//
//  Created by Alex Choi on 08/19/2014.
//  Copyright (c) 2014 Alex Choi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AXCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AXCAppDelegate class]));
    }
}
